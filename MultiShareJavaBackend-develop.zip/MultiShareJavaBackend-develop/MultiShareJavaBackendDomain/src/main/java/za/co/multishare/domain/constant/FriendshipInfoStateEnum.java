package za.co.multishare.domain.constant;

public enum FriendshipInfoStateEnum {

    PENDING,
    FRIENDS,
    UNFRIENDED,
    BLOCKED
}
